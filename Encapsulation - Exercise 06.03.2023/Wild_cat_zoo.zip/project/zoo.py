from typing import List

from project.animal import Animal
from project.worker import Worker
from project.cheetah import Cheetah
from project.lion import Lion
from project.tiger import Tiger


class Zoo:
    def __init__(self, name: str, budget: int, animal_capacity: int, workers_capacity: int):
        self.name = name
        self.__budget = budget
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.animals: List[Animal] = []         # [Lion("Simba", "Male", 4), Tiger("Zuba", "Male", 3)]
        self.workers: List[Worker] = []         # [Keeper("Anna", 31, 95), Caretaker("Bill", 21, 68)]

    def add_animal(self, animal: Animal, price: int) -> str:
        if self.__budget < price:
            return "Not enough budget"
        if not self.__animal_capacity:
            return "Not enough space for animal"
        self.animals.append(animal)
        self.__budget -= price
        self.__animal_capacity -= 1
        return f"{animal.name} the {type(animal).__name__} added to the zoo"

    def hire_worker(self, worker):
        if len(self.workers) == self.__workers_capacity:
            return "Not enough space for worker"
        self.workers.append(worker)
        return f"{worker.name} the {type(worker).__name__} hired successfully"

    def fire_worker(self, worker_name: str):
        try:
            worker = next(filter(lambda w: w.name == worker_name, self.workers))
        except StopIteration:
            return f"There is no {worker_name} in the zoo"
        self.workers.remove(worker)
        return f"{worker_name} fired successfully"

    def pay_workers(self):
        left_budget = self.__budget - sum(w.salary for w in self.workers)
        if left_budget <= 0:
            return "You have no budget to pay your workers. They are unhappy"
        self.__budget = left_budget
        return f"You payed your workers. They are happy. Budget left: {left_budget}"

    def tend_animals(self):
        left_budget = self.__budget - sum([a.money_for_care for a in self.animals])
        if left_budget <= 0:
            return "You have no budget to tend the animals. They are unhappy."
        self.__budget = left_budget
        return f"You tended all the animals. They are happy. Budget left: {left_budget}"

    def profit(self, amount):
        self.__budget += amount

    def animals_status(self):
        lions = list(filter(lambda l: type(l) == Lion, self.animals))
        tigers = list(filter(lambda t: type(t) == Tiger, self.animals))
        cheetahs = list(filter(lambda c: type(c) == Cheetah, self.animals))

        result = [f"You have {len(self.animals)} animals",
                  f"----- {len(lions)} Lions:"]
        result.extend(lions)
        result.append(f"----- {len(tigers)} Tigers:")
        result.extend(tigers)
        result.append(f"----- {len(cheetahs)} Cheetahs:")
        result.extend(cheetahs)

        return "\n".join(str(a) for a in result)

    def workers_status(self):
        info = {"Keeper": [], "Caretaker": [], "Vet": []}
        [info[type(i).__name__].append(i) for i in self.workers]

        result = [f"You have {len(self.workers)} workers",
                  f"----- {len(info['Keeper'])} Keepers:"]
        result.extend(info["Keeper"])
        result.append(f"----- {len(info['Caretaker'])} Caretakers:")
        result.extend(info["Caretaker"])
        result.append(f"----- {len(info['Vet'])} Vets:")
        result.extend(info["Vet"])

        return "\n".join(str(a) for a in result)